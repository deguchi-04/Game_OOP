#include <string>
#include <vector>
#include <iostream>
#include <random>
#include <stdlib.h>
#include <math.h>


 

using namespace std;

class BoardLevel{
    public:
    
    vector<vector<char>> v;
    int numLinhas;
    int numColunas;
};